"""Záložka Kaskáda: ladění vnitřní a vnější smyčky a simulace kaskády."""
import numpy as np
import streamlit as st

from ...core import (MODELS, default_tc, outer_with_inner, predict, tune)
from ...i18n import T
from .. import cache
from ..cache import cascade_sim, fit_model, pidconl_sim
from ..charts import mkfig, show, style, tr
from ..theme import C_MV, C_PV, C_SET2, C_SP
from ..widgets import model_name, num, seg, sld

ss = st.session_state

def render(ctx):
    """Záložka Kaskáda."""
    H, Ts, base_ctrl, diffgain, fname, model, samp, sel_mask, sigs, ts_id = ctx.H, ctx.Ts, ctx.base_ctrl, ctx.diffgain, ctx.fname, ctx.model, ctx.samp, ctx.sel_mask, ctx.sigs, ctx.ts_id
    EP, M, lab_pv, lab_t = ctx.EP, ctx.M, ctx.lab_pv, ctx.lab_t
    with ctx.tabs["cascade"]:
        st.caption(ctx.block_summary)
        st.markdown(T("cas_intro"))
        if model is None:
            st.info(T("need_model"), icon=":material/arrow_back:")
        else:
            with st.container(border=True):
                st.markdown(f"**{T('cas_inner')}**")
                isrc = seg(st, T("cas_src"), ["data", "manual"], "manual", "cas_src",
                                            format_func=lambda x: T("cas_src_" + x), help=T("h_cas_src")) or "manual"
                inner = None
                if isrc == "data":
                    i1, i2, i3, i4 = st.columns(4)
                    c_ipv = i1.selectbox(T("cas_ipv"), sigs, key=f"cas_ipv|{fname}", help=T("h_cas_ipv"))
                    c_imv = i2.selectbox(T("cas_imv"), sigs, key=f"cas_imv|{fname}", help=T("h_cas_imv"))
                    ipv_raw = ctx.on_grid(c_ipv)
                    ilo = num(T("cas_ilo"), f"cas_ilo|{c_ipv}", float(np.floor(np.nanmin(ipv_raw))), i3, help=T("h_cas_irange"))
                    ihi = num(T("cas_ihi"), f"cas_ihi|{c_ipv}", float(np.ceil(np.nanmax(ipv_raw))), i4, help=T("h_cas_irange"))
                    if st.button(T("cas_fit"), icon=":material/play_arrow:"):
                        ipv = (ipv_raw[sel_mask] - ilo) / max(ihi - ilo, 1e-9) * 100
                        imv = M(ctx.on_grid(c_imv, zoh=True)[sel_mask])
                        k = int(np.ceil(len(ts_id) / 2500))
                        best_i = None
                        for cc_ in ("P1D", "P2D"):
                            try:
                                r_ = fit_model(cc_, ts_id[::k], ipv[::k], imv[::k], Ts * k)
                                r_["fit"] = predict(cc_, r_["p"], [], ts_id, ipv, imv, [], Ts)[1]
                                if best_i is None or r_["fit"] > best_i["fit"] + 0.5:
                                    best_i = r_
                            except Exception as ex:
                                st.error(T(str(ex)))
                        if best_i:
                            ss.inner_fit = best_i
                    if ss.get("inner_fit"):
                        inner = (ss.inner_fit["code"], ss.inner_fit["p"])
                        st.caption(T("cas_inner_fit", m=model_name(inner[0]), f=f"{ss.inner_fit['fit']:.1f}",
                                     p=", ".join(f"{n} = {v:.4g}" for n, v in zip(MODELS[inner[0]]["params"], inner[1]))))
                else:
                    i1, i2, i3, i4 = st.columns(4)
                    k_i = num("K", "cas_k", 1.0, i1, format="%.4g", help=T("h_cas_k"))
                    t1_i = num("T1 [s]", "cas_t1", 5.0, i2, min_value=1e-3, help=T("help_T"))
                    t2_i = num("T2 [s]", "cas_t2", 0.0, i3, min_value=0.0, help=T("help_T"))
                    th_i = num("θ [s]", "cas_th", 1.0, i4, min_value=0.0, help=T("help_theta"))
                    inner = ("P2D", [k_i, max(t1_i, t2_i), max(min(t1_i, t2_i), 1e-3), th_i]) if t2_i > 0 else \
                        ("P1D", [k_i, t1_i, th_i])
            if inner is None:
                st.info(T("cas_need_inner"))
            else:
                ci_, p_i = inner
                with st.container(border=True):
                    st.markdown(f"**{T('cas_inner_tune')}**")
                    j1, j2, j3 = st.columns([1.3, 1, 2])
                    im = seg(j1, T("method"), ["SIMC", "AMIGO", "OPT"], "SIMC", "cas_im",
                                              format_func=lambda x: T("m_" + x)) or "SIMC"
                    samp_i = num(T("cas_samp"), "cas_samp", samp, j2, min_value=0.001, help=T("sampletime_help"))
                    if im == "SIMC":
                        tci0 = default_tc(ci_, p_i, samp_i)
                        tci = sld(j3, T("tc"), float(max(0.05 * tci0, 1e-3)), float(10 * tci0), float(tci0), "cas_tci",
                                  help=T("tc_help"))
                        si = tune(ci_, p_i, "SIMC", tci, "PI", samp_i)
                    elif im == "AMIGO":
                        si = tune(ci_, p_i, "AMIGO", None, "PI", samp_i)
                    else:
                        r0 = tune(ci_, p_i, "SIMC", default_tc(ci_, p_i, samp_i), "PI", samp_i)
                        si = cache.opt_migo(ci_, tuple(p_i), "PI", samp_i, diffgain, 1.6, None, ((r0["Kc"], r0["Ti"], 0.0),))
                    st.caption(T("mdesc_" + im) + (f" {T('cdesc_MIGO')}" if im == "OPT" else ""))
                    ictrl = dict(Gain=si["Kc"], TI=si["Ti"], TD=0.0, DiffGain=diffgain, SampleTime=samp_i, MV_Lo=0.0,
                                 MV_Hi=100.0, PropFbk=False, DiffFbk=True)
                    # efektivní časová konstanta uzavřené vnitřní smyčky ze simulace skoku SP
                    Tsim = 30 * (p_i[-1] + sum(p_i[1:-1]) + samp_i)
                    hi_ = samp_i / max(1, min(10, int(6000 * samp_i / Tsim)))
                    ni_ = int(Tsim / hi_) + 1
                    spi_ = np.ones(ni_)
                    spi_[0] = 0
                    tt_i, _, P_i, _ = pidconl_sim(ci_, p_i, [], hi_, spi_, 0.0, 50.0, ictrl)
                    k63 = np.argmax(P_i >= 0.632) if np.any(P_i >= 0.632) else len(P_i) - 1
                    tci_eff = max(tt_i[k63] - p_i[-1], hi_)
                    k1, k2, k3 = st.columns(3)
                    k1.metric("Gain", f"{si['Kc']:.4g}")
                    k2.metric("TI [s]", f"{si['Ti']:.4g}")
                    k3.metric(T("cas_t63"), f"{tt_i[k63]:.3g} s", help=T("h_cas_t63"))
                with st.container(border=True):
                    st.markdown(f"**{T('cas_outer_tune')}**")
                    co_, p_o = outer_with_inner(model[0], model[1], tci_eff, p_i[-1])
                    st.caption(T("cas_outer_model", m=model_name(co_),
                                 p=", ".join(f"{n} = {v:.4g}" for n, v in zip(MODELS[co_]["params"], p_o))))
                    l1, l2, l3 = st.columns([1.3, 0.8, 2])
                    om = seg(l1, T("method"), ["SIMC", "AMIGO", "OPT"], "SIMC", "cas_om",
                                              format_func=lambda x: T("m_" + x)) or "SIMC"
                    oct_ = seg(l2, T("ctrl_type"), ["PI", "PID"], "PI", "cas_oct") or "PI"
                    tco = None
                    if om == "SIMC":
                        tco0 = default_tc(co_, p_o, samp)
                        tco = sld(l3, T("tc"), float(max(0.05 * tco0, 1e-3)), float(10 * tco0), float(tco0), "cas_tco",
                                  help=T("tc_help"))
                        so = tune(co_, p_o, "SIMC", tco, oct_, samp)
                    elif om == "AMIGO":
                        so = tune(co_, p_o, "AMIGO", None, oct_, samp)
                    else:
                        r0 = tune(co_, p_o, "SIMC", default_tc(co_, p_o, samp), oct_, samp)
                        so = cache.opt_migo(co_, tuple(p_o), oct_, samp, diffgain, 1.6, None, ((r0["Kc"], r0["Ti"], r0["Td"]),))
                    st.caption(T("mdesc_" + om) + (f" {T('cdesc_MIGO')}" if om == "OPT" else ""))
                    octrl = dict(base_ctrl, Gain=so["Kc"], TI=so["Ti"], TD=so["Td"], MV_Lo=0.0, MV_Hi=100.0)
                    o1, o2, o3, o4 = st.columns(4)
                    o1.metric("Gain", f"{so['Kc']:.4g}")
                    o2.metric("TI [s]", f"{so['Ti']:.4g}")
                    o3.metric("TD [s]", f"{so['Td']:.4g}")
                    ratio_sep = (tco or so["Ti"] / 4) / max(tt_i[k63], 1e-9)
                    o4.metric(T("cas_sep"), f"{ratio_sep:.1f}×", help=T("h_cas_sep"))
                    if ratio_sep < 4:
                        st.warning(T("cas_sep_warn"), icon=":material/warning:")
                # simulace kaskády
                Tc_sim = max(15 * (p_o[-1] + (p_o[1] if co_ in ("P1D", "P2D", "I1D") else 0) + (tco or 0)), 50 * samp)
                hc = min(samp, samp_i) / max(1, min(5, int(15000 * min(samp, samp_i) / Tc_sim)))
                nc = int(Tc_sim / hc) + 1
                tcs = np.arange(nc) * hc
                sp_o = np.full(nc, 50.0)
                sp_o[tcs >= 0.05 * Tc_sim] = 55.0
                d_i = np.where(tcs >= 0.4 * Tc_sim, 5.0, 0.0)
                d_o = np.where(tcs >= 0.7 * Tc_sim, 5.0, 0.0)
                tcs, oc = cascade_sim((ci_, p_i), ictrl, (model[0], model[1]), octrl, hc, sp_o, d_i, d_o)
                if np.all(np.isfinite(oc)) and np.abs(oc).max() < 1e5:
                    fc = mkfig(3, [0.45, 0.3, 0.25])
                    fc.add_trace(tr(tcs, EP(oc[:, 0]), "SP", C_SP, 1.4, "dash", "hv"), 1, 1)
                    fc.add_trace(tr(tcs, EP(oc[:, 1]), T("cas_pv_o"), C_PV, 2.0), 1, 1)
                    fc.add_trace(tr(tcs, oc[:, 2], T("cas_sp_i"), C_SP, 1.4, "dash"), 2, 1)
                    fc.add_trace(tr(tcs, oc[:, 3], T("cas_pv_i"), C_SET2, 2.0), 2, 1)
                    fc.add_trace(tr(tcs, oc[:, 4], T("cas_valve"), C_MV, 1.8), 3, 1)
                    show(style(fc, H + 80, [lab_pv, T("cas_inner_pct"), T("cas_valve_pct")], lab_t, rev="cas"),
                         key="chart_cas", fname="cascade", report=T("tab7"))
                    st.caption(T("cas_sim_help"))
                else:
                    st.error(T("err_sim_unstable", n=T("tab7")))


